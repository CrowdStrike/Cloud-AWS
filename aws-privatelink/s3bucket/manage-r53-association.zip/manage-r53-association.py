
import json
import boto3
import urllib3
import json
import logging
import requests
from optparse import OptionParser
http = urllib3.PoolManager()

logger = logging.getLogger()
logger.setLevel(logging.INFO)
ch = logging.StreamHandler()
ch.setLevel(logging.INFO)
formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
ch.setFormatter(formatter)
logger.addHandler(ch)

SUCCESS = "SUCCESS"
FAILED = "FAILED"

class zone_attach(object):
    reason = None
    response_data = None

    def __init__(self, event, context):
        self.event = event
        self.context = context
        logger.info("Event: %s" % self.event)
        logger.info("Context: %s" % self.context)
        self.route53 = boto3.session.Session().client('route53')

        self.vpc_id = event['ResourceProperties']['VpcId']
        self.hosted_zone_id = event['ResourceProperties']['HostedZoneId']
        self.region = event['ResourceProperties']['Region']


    def create(self, updating=False):
        try:
            response = self.route53.associate_vpc_with_hosted_zone(
                HostedZoneId=self.hosted_zone_id,
                VPC={
                    'VPCRegion': self.region,
                    'VPCId': self.vpc_id
                }
            )
            logger.info("Response: %s" % response)
            if not updating:
                self.send_status(SUCCESS)
        except Exception as e:
            self.reason = "Create Vpc Hosted Zone association call Failed %s" % e
            logger.error(self.reason)
            if self.context:
                self.send_status(FAILED)
            return

    def delete(self, updating=False):
        if updating:
            hosted_zone = self.event['OldResourceProperties']['HostedZoneId']
            vpc_id = self.event['OldResourceProperties']['VpcId']
            region = self.event['OldResourceProperties']['Region']
            logger.info("Update dissociate: %s from %s" % (vpc_id,hosted_zone))
        else:
            hosted_zone = self.hosted_zone_id
            vpc_id = self.vpc_id
            region = self.region
            logger.info("Dissociate: %s from %s" % (vpc_id,hosted_zone))
        try:
            self.route53.disassociate_vpc_from_hosted_zone(
                HostedZoneId=hosted_zone,
                VPC={
                    'VPCRegion': region,
                    'VPCId': vpc_id
                }
            )
            if not updating:
                self.send_status(SUCCESS)
        except Exception as e:
            self.reason = "Delete Vpc Hosted Zone association call Failed %s" % e
            logger.error(self.reason)
            if self.context:
                self.send_status(FAILED)
            return

    def update(self):
        self.create(updating=True)
        self.delete(updating=True)
        self.send_status(SUCCESS)

    def send_status(self, PASS_OR_FAIL):
        send(
            self.event,
            self.context,
            PASS_OR_FAIL,
            responseData = self.response_data
            # reason = self.reason,
        )


def send(event, context, responseStatus, responseData, physicalResourceId=None, noEcho=False):
    responseUrl = event['ResponseURL']

    print(responseUrl)

    responseBody = {}
    responseBody['Status'] = responseStatus
    responseBody['Reason'] = 'See the details in CloudWatch Log Stream: ' + context.log_stream_name
    responseBody['PhysicalResourceId'] = physicalResourceId or context.log_stream_name
    responseBody['StackId'] = event['StackId']
    responseBody['RequestId'] = event['RequestId']
    responseBody['LogicalResourceId'] = event['LogicalResourceId']
    responseBody['NoEcho'] = noEcho
    responseBody['Data'] = responseData

    json_responseBody = json.dumps(responseBody)

    print("Response body:\n" + json_responseBody)

    headers = {
        'content-type': '',
        'content-length': str(len(json_responseBody))
    }

    try:

        response = http.request('PUT', responseUrl, body=json_responseBody.encode('utf-8'), headers=headers)
        print("Status code: " + response.reason)
    except Exception as e:
        print("send(..) failed executing requests.put(..): " + str(e))


def lambda_handler(event, context):
    attachment = zone_attach(event, context)
    if event['RequestType'] == 'Delete':
        attachment.delete()
        return
    if event['RequestType'] == 'Create':

        attachment.create()
        return
    if event['RequestType'] == 'Update':
        attachment.update()
        return
    logger.info("Received event: " + json.dumps(event, indent=2))
    if context:
        send(event, context, FAILED, reason="Unknown Request Type %s" % event['RequestType'])

