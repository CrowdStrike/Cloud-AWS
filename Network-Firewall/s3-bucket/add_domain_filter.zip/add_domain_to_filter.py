import json
import logging
import os
import requests
import boto3
from classes import detects

falcon_client_secret = os.environ['falcon_client_secret']
falcon_client_id = os.environ['falcon_client_id']



logger = logging.getLogger(__name__)
logger.setLevel(level=logging.INFO)

vpcfw_client = boto3.client('vpcfirewall')

def update_domain_rule_group(domain_rule_group_name: str, domain_list: list, update_token: str):
    rg_type = 'STATEFUL'
    try:
        response = vpcfw_client.update_rule_group(
            RuleGroupName=domain_rule_group_name,
            RuleGroup={
                'RulesSource': {
                    'RulesSourceList': {
                        'Targets': domain_list,
                        'TargetType': [
                            'TLS_SNI', 'HTTP_HOST',
                        ],
                        'GeneratedRulesType': 'DENYLIST'
                    },
                }
            },
            Type='STATEFUL',
            Description='string',
            UpdateToken=update_token,
            DryRun=False
        )
        print(response)
        return response
    except Exception as e:
        print(e)
        return


def describe_rule_group(rg_name: str, type: str):

    try:
        result = vpcfw_client.describe_rule_group(
            RuleGroupName=rg_name,
            # RuleGroupArn=rg_arn,
            Type=type)
        if result['ResponseMetadata']['HTTPStatusCode'] == 200:
            return result
        else:
            return
    except vpcfw_client.exceptions.ResourceNotFoundException:
        print('Resource group {} not found'.format(rg_name))
        return
    except Exception as e:
        print(f'Exception calling create_rule_group {e}')
        exit()

def get_auth_header(auth_token) -> str:
    if auth_token:
        auth_header = "Bearer " + auth_token
        headers = {"Authorization": auth_header}
        return headers


def get_auth_token():
    url = "https://api.crowdstrike.com/oauth2/token"
    payload = "client_secret=" + falcon_client_secret + "&client_id=" + falcon_client_id
    headers = {"Content-Type": "application/x-www-form-urlencoded"}
    response = requests.request("POST", url, headers=headers, data=payload)
    if response.ok:
        response_object = response.json()
        token = response_object.get("access_token", "")
        if token:
            return token
    return


def lambda_handler(event, context):
    global vpcfw_client
    lambda_root = os.environ.get('LAMBDA_TASK_ROOT')
    models_path = os.path.join(lambda_root, 'models')
    aws_data_path = set(os.environ.get('AWS_DATA_PATH', '').split(os.pathsep))
    aws_data_path.add(models_path)
    os.environ.update({'AWS_DATA_PATH': os.pathsep.join(aws_data_path)})
    env_data_path = os.environ.get('AWS_DATA_PATH')
    env_lambda_root = os.environ.get('LAMBDA_TASK_ROOT')

    logger.info('env_data_path={}'.format(env_data_path))
    logger.info('env_lambda_root={}'.format(env_lambda_root))
    vpcfw_client = boto3.client(service_name='vpcfirewall')
    logger.info('Event = {}'.format(event))
    try:
        finding = event['detail']['findings'][0]
    except KeyError:
        logger.info('Cant get finding info')
        exit()
    finding_id = finding['Id']
    str_elements = finding_id.split(':')
    logger.info('str_elements {}'.format(str_elements))
    aid = str_elements[1].strip()
    fid = str_elements[2].strip()
    cs_finding_query = {
        "ids": [
            f"ldt:{aid}:{fid}"
        ]
    }
    logger.info(cs_finding_query)
    token = get_auth_token()
    mydetects = detects.Detects(token)
    detect_details = mydetects.GetDetectSummaries((cs_finding_query))
    logger.info(detect_details)
    if detect_details:
        try:
            domain = detect_details['body']['resources'][0]['behaviors'][0]['ioc_value']
            logger.info(domain)
        except KeyError:
            logger.info('No Domain information exists')
            exit()
        except Exception as e:
            logger.info('General exception {}'.format(e))
    else:
        logger.info('No detection summary data')
        exit()
    rg_name = 'domain-deny-list'
    rg_type = 'STATEFUL'

    rg_info = describe_rule_group(rg_name, rg_type)
    try:
        targets = rg_info['RuleGroup']['RulesSource']['RulesSourceList']['Targets']
    except KeyError:
        logger.info('Failed to get existing domains')
        targets = []
    rg_update_token = rg_info.get('UpdateToken')
    if rg_update_token:
        if domain in targets:
            logger.info('Domain {} already exists in list'.format(domain))
            exit()
        else:
            targets.append(domain)
            result = update_domain_rule_group(rg_name, targets, rg_update_token)
            if result['ResponseMetadata']['HTTPStatusCode'] ==200:
                logger.info('Successfully update domain filter with {}'.format(targets))
            else:
                logger.info('Failed to update domain filter')
    domain_rg = describe_rule_group('domain-deny-list', 'STATEFUL')
    print(domain_rg)



    # filter="device.device_id:'a1a045e2bcf04aa8bd91803573874c9d''"

    # query = mydetects.QueryDetects(filter)


if __name__ == '__main__':
    context =()
    event = {
   "version": "0",
   "id": "5783dc79-7bcb-efcd-84fd-838531b8d0c8",
   "detail-type": "Security Hub Findings - Custom Action",
   "source": "aws.securityhub",
   "account": "517716713836",
   "time": "2020-10-13T14:22:52Z",
   "region": "us-west-1",
   "resources": [
      "arn:aws:securityhub:us-west-1:517716713836:action/custom/CSCreateDomainFilter"
   ],
   "detail": {
      "actionName": "CreateDomainFilter",
      "actionDescription": "Create Domain Filter from Crowdstrike IOC",
      "findings": [
         {
            "ProductArn": "arn:aws:securityhub:us-west-1:517716713836:product/crowdstrike/crowdstrike-falcon",
            "Types": [
               "Namespace: TTPs",
               "Category: Falcon Intel",
               "Classifier: Intelligence Indicator - Domain"
            ],
            "SourceUrl": "https://falcon.crowdstrike.com/activity/detections/detail/a1a045e2bcf04aa8bd91803573874c9d/4297552959?_cid=797bcd0bf5ae4f39a2b770ff52517125",
            "Description": "A domain lookup matched a CrowdStrike Intelligence indicator that has previously been used in targeted attacks.",
            "SchemaVersion": "2018-10-08",
            "GeneratorId": "Falcon Host",
            "CreatedAt": "2020-10-11T19:52:27Z",
            "RecordState": "ACTIVE",
            "Title": "Falcon Alert. Instance: i-006191f26af245a50",
            "Workflow": {
               "Status": "NEW"
            },
            "Severity": {
               "Normalized": 80,
               "Label": "HIGH",
               "Product": 4
            },
            "Process": {
               "Path": "\\Device\\HarddiskVolume1\\Windows\\System32",
               "Name": "PING.EXE"
            },
            "UpdatedAt": "2020-10-11T19:55:33.406350Z",
            "WorkflowState": "NEW",
            "ProductFields": {
               "aws/securityhub/FindingId": "arn:aws:securityhub:us-west-1:517716713836:product/crowdstrike/crowdstrike-falcon/i-006191f26af245a50ldt:a1a045e2bcf04aa8bd91803573874c9d:4297552959",
               "aws/securityhub/ProductName": "CrowdStrike Falcon",
               "aws/securityhub/CompanyName": "CrowdStrike"
            },
            "AwsAccountId": "517716713836",
            "Id": "i-006191f26af245a50ldt:a1a045e2bcf04aa8bd91803573874c9d:4297552959",
            "Resources": [
               {
                  "Type": "AwsEc2Instance",
                  "Region": "None",
                  "Id": "i-006191f26af245a50"
               }
            ]
         }
      ]
   }
}
    lambda_handler(event,context)