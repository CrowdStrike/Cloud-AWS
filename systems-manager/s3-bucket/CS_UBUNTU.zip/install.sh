#!/bin/bash
sudo apt-get install awscli -y
echo 'Starting'
REGION=`curl http://169.254.169.254/latest/dynamic/instance-identity/document|grep region|awk -F\" '{print $4}'`
echo $REGION
echo 'Configuring region'
aws configure set region $REGION

#aws Getting 
echo 'Getting CID'
CCID=`aws ssm get-parameter --name AgentActivationKey --query 'Parameter.Value' --output text`

#installing from current directory
sudo dpkg -i falcon-sensor.deb
sudo apt-get -f -y install

#Configuring Falconsensor
eval /opt/CrowdStrike/falconctl -s --cid="$CCID"

#Starting Falcon sensor
if [[ -L "/sbin/init" ]]
then
    systemctl start falcon-sensor
else
    sudo service falcon-sensor start
fi


# Verification
if [[ -n $(ps -e | grep falcon-sensor) ]]
then
  echo "Successfully finished installation..."
else
  echo "Installation failed..."
  exit 1
fi

