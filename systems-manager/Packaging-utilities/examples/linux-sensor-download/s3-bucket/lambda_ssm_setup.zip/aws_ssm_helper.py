#!/usr/bin/python
import boto3
from botocore.exceptions import ClientError
import sys
import time

# Constants to be used

AUTOMATION_CONFIG_SECTION = 'AUTOMATION'
MANIFEST_FILE_NAME = 'manifest.json'
VERIFY_SSM_PACKAGE_RETRY_COUNT = 60
VERIFY_SSM_PACKAGE_SLEEP_SEC = 5



#################################
# AWS EC2 client helper functions
#################################

def __describe_regions(client):
    return [region['RegionName'] for region in client.describe_regions()['Regions']]


##################################
# AWS SSM client helper functions
##################################
def __describe_instances(client, filters):
    return client.describe_instances(
        Filters=filters)


def __create_document(client, s3bucket, logger, document_name, version_name, document_type, content_file_path, attachments):
    # with open(content_file_path) as openFile:
    s3_client = boto3.client('s3')
    try:
        s3_object = s3_client.get_object(Bucket=s3bucket, Key=content_file_path)
    except Exception as e:
        print_log_info(logger,"Exception {} fetching {} from bucket {}".format(e, content_file_path,s3bucket))
    data = s3_object.get('Body').read().decode('utf-8')
    documentContent = data


    args = {
        'Name': document_name,
        'DocumentType': document_type,
        'Content': documentContent,
    }

    if 'yml' in content_file_path:
        args['DocumentFormat'] = 'YAML'

    if len(attachments) > 0:
        args['Attachments'] = attachments

    if len(version_name) > 0:
        args['VersionName'] = version_name
    return client.create_document(**args)


def __delete_document(client, document_name, document_version, version_name):
    args = {
        'Name': document_name,
    }
    if len(version_name) > 0:
        args['VersionName'] = version_name

    if len(document_version) > 0:
        args['DocumentVersion'] = document_version

    return client.delete_document(**args)


def __describe_document(client, document_name, document_version, version_name):
    args = {
        'Name': document_name
    }

    if len(version_name) > 0:
        args['VersionName'] = version_name

    if len(document_version) > 0:
        args['DocumentVersion'] = document_version

    return client.describe_document(**args)


def __describe_document_permission(client, document_name):
    args = {
        'Name': document_name,
        'PermissionType': 'Share'
    }
    return client.describe_document_permission(**args)


def __modify_document_permission(client, document_name, shared_document_version, account_ids_to_add,
                                 account_ids_to_remove):
    ########################################################
    # WARN : today aws does not support passing document version and make the operation at the package level
    ########################################################
    args = {
        'Name': document_name,
        'PermissionType': 'Share',
        'SharedDocumentVersion': shared_document_version,
    }

    if len(account_ids_to_add) > 0:
        args['AccountIdsToAdd'] = account_ids_to_add
    if len(account_ids_to_remove) > 0:
        args['AccountIdsToRemove'] = account_ids_to_remove

    return client.modify_document_permission(**args)


def __list_document_versions(client, document_name):
    args = {
        'Name': document_name,
    }

    return client.list_document_versions(**args)


def __update_document_default_version(client, document_name, document_version):
    return client.update_document_default_version(
        Name=document_name,
        DocumentVersion=document_version
    )


def __start_automation_execution(client, document_name, document_version, parameters):
    return client.start_automation_execution(
        DocumentName=document_name,
        DocumentVersion=document_version,
        Parameters=parameters,
    )


def __get_automation_execution(client, id):
    return client.get_automation_execution(
        AutomationExecutionId=id
    )


def __describe_instance_status(client, ids):
    return client.describe_instance_status(
        InstanceIds=ids
    )


def __send_command(client, command_name, document_version, parameters, instance_ids):
    return client.send_command(
        DocumentName=command_name,
        DocumentVersion=document_version,
        Parameters=parameters,
        InstanceIds=instance_ids)


def __get_command_invocation(client, command_id, instance_id):
    return client.get_command_invocation(
        CommandId=command_id,
        InstanceId=instance_id)


###########################
# aws_ssm* scripts helper Functions
###########################

# Shared Func
# Creates a new FalconSensor* type distributor package or updated an existing package with new version and ensures the package is active.
def create_ssm_distributor_package(session, logger, regions, package_name, package_version_name,
                                   manifest_file_path, s3_bucket_path):
    print_log_info(logger,
                   "Starting build and publish of new distributor package {} with version name {}".format(package_name,
                                                                                                          package_version_name))
    attachments = [{
        'Key': 'SourceUrl',
        'Values': ['s3://' + s3_bucket_path + '/falcon']
    }]
    document_version = '$LATEST',
    document_type = 'Package'

    for region in regions:
        start_time = time.time()
        print_log_info(logger,
                       "... starting build and publish of new distributor package version to region {}".format(region))
        ssm_client = session.client('ssm', region_name=region)

        # Adding a new distributor package or new version to an existing distributor package
        try:
            # Describe package to ensure package exists and version does not exists
            verify_ssm_document_is_active_with_retry(ssm_client, logger, package_name, "", package_version_name)
        except ClientError as e:
            try:
                if 'InvalidDocument' in str(e) and \
                        'Document with name {} does not exist'.format(package_name) in str(e):

                    print_log_warn(logger,
                                   "... No existing distributor package with name {}. Error : {}".format(package_name,
                                                                                                         e))
                    print_log_info(logger,
                                   "... Creating NEW distributor package {} with version {}".format(package_name,
                                                                                                    package_version_name))

                    __create_document(ssm_client, s3_bucket_path, logger, package_name, package_version_name, document_type, manifest_file_path,
                                      attachments)

                else:
                    print_log_error(logger,
                                    "Error while performing describe document in region {}. Error: {}".format(
                                        region, e),
                                    True)
            except ClientError as e:
                print_log_error(logger,
                                "Failed to build and publish new distributor package version in region {}. Error {}".format(
                                    region, e),
                                True)
        else:
            print_log_error(logger,
                            "Failed as distributor package {} with version {} already exists in region {}.".format(
                                package_name, package_version_name, region), True)

        # Verify package was successfully added
        try:
            # Describe package to ensure package exists and version does not exists
            active, error = verify_ssm_document_is_active_with_retry(ssm_client, logger, package_name, "",
                                                                     package_version_name)
            if active:
                print_log_info(logger,
                               "... Successfully verified distributor package version {} is in active state".format(
                                   package_version_name))
                return True
            else:
                print_log_error(logger,
                                "Published distributor package version {} is not in active state. Error {}".format(
                                    package_version_name, error),
                                True)
        except ClientError as e:
            print_log_error(logger,
                            "Error while verifying distributor package in region {}. Error: {}".format(region, e),
                            True)

        print_log_info(logger,
                       "Successfully completed build and publish of new distributor package version to region {}. Took {}s".format(
                           region, time.time() - start_time))


# Shared Func
# Creates a new automation document like Crowdstrike-FalconSensorDeploy or updated an existing document with new version and ensures the document is active.
def create_or_update_ssm_automation_document(session, s3bucket, logger, regions, action, document_name,
                                             file_path):
    document_version = "$LATEST",
    document_type = 'Automation'
    print_log_info(logger, "Starting {} action for automation document {}".format(action, document_name))

    for region in regions:
        start_time = time.time()
        ssm_client = session.client('ssm', region_name=region)
        try:
            if action == "create":
                print_log_info(logger,
                               "... Creating NEW automation document in region {}".format(region))
                response = __create_document(ssm_client, s3bucket, logger, document_name, "", document_type, file_path,
                                             "")
            elif action == "update":
                print_log_info(logger,
                               "Update not supported")


            stored_document_version = response['DocumentDescription']["DocumentVersion"]
            active, error = verify_ssm_document_is_active_with_retry(ssm_client, logger, document_name,
                                                                     stored_document_version,
                                                                     "")
            if active:
                print_log_info(logger,
                               "... Successfully verified automation document version {} is in active state in region {}".format(
                                   stored_document_version, region))
                return True
            else:
                print_log_error(logger,
                                "Published distributor package version {} is not in active state. Error {}".format(
                                    stored_document_version, error),
                                True)
        except ClientError as e:
            print_log_error(logger,
                            "Failed to create new automation package in region {}. Error {}".format(
                                region, e),
                            True)




# Shared def
# This function verifies is document is active
def verify_ssm_document_is_active_with_retry(client, logger, document_name, document_version, version_name):
    print_log_info(logger,
                   "Verifying document {} with document_version '{}' or version_name ='{}' is active".format(
                       document_name,
                       document_version,
                       version_name))
    for x in range(VERIFY_SSM_PACKAGE_RETRY_COUNT):
        describe_response = __describe_document(client, document_name, document_version, version_name)
        if describe_response['Document']['Status'] == 'Active':
            return True, ""
        if describe_response['Document']['Status'] == 'Failed':
            return False, describe_response['Document']['StatusInformation']

        # print_log_info(logger,
        #               "... ... {}/{} Retrying : status check".format(x, VERIFY_SSM_PACKAGE_RETRY_COUNT))
        time.sleep(VERIFY_SSM_PACKAGE_SLEEP_SEC)
    return False


# Shared def
# This function deletes an SSM document with wait
def delete_ssm_document(session, logger, regions, document_name, document_version, version_name, log_string):
    print_log_info(logger,
                   "Starting to delete document {} with document_version '{}' or version_name ='{}'".format(
                       document_name,
                       document_version,
                       version_name))


    for region in regions:
        ssm_client = session.client('ssm', region_name=region)
        print_log_info(logger, "... Deleting document {} with version {} in region {}".format(document_name,
                                                                                              document_version,
                                                                                              region))
        try:
            __delete_document(ssm_client, document_name, document_version, version_name)
        except ClientError as e:
            if 'InvalidDocument' in str(e) and 'does not exist' in str(e):
                print_log_warn(logger,
                               "... Document does not exist in region {}. Error: {}".format(region, e))
            else:
                print_log_error(logger,
                                "Failed to delete document in region {}. Error: {}".format(region, e),
                                True)

        print_log_info(logger, "... successfully deleted document {} with version {} in region {}".format(document_name,
                                                                                                          document_version,
                                                                                                          region))


# Shared def
# This function adds wait before a action
def adding_wait(logger, log_string):
    retry_count = VERIFY_SSM_PACKAGE_RETRY_COUNT
    print_log_warn(logger, "**************************************************")
    if len(log_string) > 0:
        print_log_warn(logger, log_string)
    else:
        print_log_warn(logger, "Deleting entire SSM document")
    print_log_warn(logger, "**************************************************")
    print_log_warn(logger,
                   "Lets take it slow and think it through will wait for {} seconds before we proceed, feel free to kill the script if this was accidental".format(
                       retry_count))
    print_log_warn(logger, "**************************************************")

    for x in list(range(retry_count)[::-1]):
        print_log_info(logger, "... Time left to decide {}s".format(x))
        time.sleep(VERIFY_SSM_PACKAGE_SLEEP_SEC)


# Shared def
# This function marks an SSM document version as default
def mark_ssm_document_as_default(session, logger, regions, document_name, document_version, version_name):
    print_log_info(logger,
                   "Staring to mark document {} with document_version '{}' or version_name ='{}' as default document".format(
                       document_name,
                       document_version,
                       version_name))

    if len(version_name) > 0:
        print_log_info(logger,
                       "Retrieving document_version for the document with version_name {}".format(
                           version_name))
    region_meta_map = {}
    # ensuring package exists in target regions
    for region in regions:
        ssm_client = session.client('ssm', region_name=region)
        if len(version_name) > 0:
            print_log_info(logger,
                           "... retrieving document_version in region {}".format(region))
            try:
                # Describe package to ensure package exists and version does not exists
                describe_response = __describe_document(ssm_client, document_name, document_version, version_name)

                if describe_response['Document']['Status'] == 'Active':
                    print_log_info(logger,
                                   "... Successfully retrieve  version is in active state")
                else:
                    print_log_error(logger,
                                    "... Published document is not in active state. Error {}".format(
                                        describe_response['Document']['StatusInformation']), True)

                region_meta_map[region] = {'client': ssm_client,
                                           'target_document': describe_response['Document']['DocumentVersion']}

            except ClientError as e:
                print_log_error(logger,
                                "... Error while verifying document in region {}. Error: {}".format(region,
                                                                                                    e),
                                True)
        else:
            region_meta_map[region] = {'client': ssm_client, 'target_document': document_version}

    print_log_info(logger, "Starting marking ssm document version as default")
    for region in regions:
        print_log_info(logger,
                       "... Marking ssm document version as default in region {}".format(region))

        try:
            ssm_client = region_meta_map[region]['client']
            target_default_document = region_meta_map[region]['target_document']

            default_response = __update_document_default_version(ssm_client, document_name,
                                                                 target_default_document)
            # Verifying
            if default_response['Description']['Name'] == document_name and default_response['Description'][
                'DefaultVersion']:
                print_log_info(logger,
                               "... Successfully marked ssm document as default in region {}".format(region))
            else:
                print_log_error(logger,
                                "... Failed to marked ssm document default in region {}. Response {}".format(
                                    region, default_response),
                                True)

        except ClientError as e:
            print_log_error(logger,
                            "... Error while marking ssm document {} with document_version '{}' or version_name ='{}' as default in region {}. Error {}".format(
                                document_name, document_version, version_name, region, e),
                            True)

    print_log_info(logger,
                   "Successfully marked package {}  with document_version '{}' or version_name ='{}' as default document".format(
                       document_name, document_version, version_name))


# Shared Func
# This function modifies document permission, it can shared or unshared with another AWS accounts or `all` accounts
def modify_ssm_document_permissions(session, logger, regions, document_name, shared_document_version,
                                    account_ids_to_add, account_ids_to_remove):
    print_log_info(logger,
                   "Starting to modify permissions for document {}, shared version {} for AccountIdsToAdd={} AccountIdsToRemove={}".format(
                       document_name, shared_document_version, account_ids_to_add, account_ids_to_remove))

    if account_ids_to_add == ['all']:
        adding_wait(logger, "No account_ids_to_add provided, DOCUMENT WILL BE MADE PUBLIC TO ALL THE AWS CUSTOMES.")

    if account_ids_to_remove == ['all']:
        adding_wait(logger, "No account_ids_to_remove provided, ENTIRE DOCUMENT WILL BE MADE PRIVATE.")

    for region in regions:
        ssm_client = session.client('ssm', region_name=region)
        try:
            print_log_info(logger,
                           "... modify permissions for document in region {}".format(region))
            __modify_document_permission(ssm_client, document_name, shared_document_version, account_ids_to_add,
                                         account_ids_to_remove)
            describe_response = __describe_document_permission(ssm_client, document_name)
            print_log_info(logger,
                           "... describe document permission response, AccountIds={}, AccountSharingInfoList={}".format(
                               describe_response['AccountIds'], describe_response['AccountSharingInfoList']))
        except ClientError as e:
            print_log_error(logger,
                            "... Failed to modify permissions in region {}. Error {}".format(region, e),
                            True)


# Shared def
# This function describes an ssm document
def describe_ssm_document(session, logger, regions, document_name, document_version, version_name):
    print_log_info(logger,
                   "Starting to describe document {} with document_version '{}' or version_name ='{}'".format(
                       document_name,
                       document_version,
                       version_name))

    for region in regions:
        ssm_client = session.client('ssm', region_name=region)
        print_log_info(logger, "... Describing document in region {}".format(region))
        try:
            describe_response = __describe_document(ssm_client, document_name, document_version, version_name)
            print_log_info(logger,
                           "... Document info in region {} : \n {}".format(region, describe_response['Document']))
        except ClientError as e:
            print_log_error(logger,
                            "Failed to describe document in region {}. Error: {}".format(region, e),
                            True)


# Shared def
# This function describes an ssm document permissions
def describe_ssm_document_permission(session, logger, regions, document_name):
    print_log_info(logger,
                   "Starting to describe document {} permissions".format(document_name))

    for region in regions:
        ssm_client = session.client('ssm', region_name=region)
        print_log_info(logger, "... Describing document permissions in region {}".format(region))
        try:
            describe_response = __describe_document_permission(ssm_client, document_name)
            print_log_info(logger,
                           "... describe document permission response, AccountIds={}, AccountSharingInfoList={}".format(
                               describe_response['AccountIds'], describe_response['AccountSharingInfoList']))
        except ClientError as e:
            print_log_error(logger,
                            "Failed to describe document in region {}. Error: {}".format(region, e),
                            True)


# Shared def
# This function list all available document versions
def list_ssm_document_versions(client, document_name):
    return __list_document_versions(client, document_name)['DocumentVersions']


# Shared def
# This function starts an automation document execution
def start_ssm_automation_execution(client, document_name, document_version, parameters):
    return __start_automation_execution(client, document_name, document_version, parameters)


# Shared def
# This function get status of an automation document execution
def get_ssm_automation_execution(client, id):
    return __get_automation_execution(client, id)


# Shared def
# This function ensures the instance is in running state
def verify_ec2_instance_is_running(logger, ec2_client, instance_ids):
    print_log_info(logger, "... verifying instances in `running` state")

    region_instances_ids = instance_ids.copy()

    for x in range(VERIFY_SSM_PACKAGE_RETRY_COUNT):
        response = __describe_instance_status(ec2_client, region_instances_ids)

        for each in response['InstanceStatuses']:
            if (each['InstanceState']['Name'] == 'running' and
                    each['InstanceStatus']['Status'] == 'ok' and
                    each['SystemStatus']['Status'] == 'ok'):
                region_instances_ids.remove(each['InstanceId'])
        if len(region_instances_ids) == 0:
            break
        time.sleep(VERIFY_SSM_PACKAGE_SLEEP_SEC)

    if len(region_instances_ids) > 0:
        print_log_error(logger, "Instances {} not in ready state".format(region_instances_ids),
                        True)


def execute_update_ssm_command(logger, ssm_client, instance_ids):
    print_log_info(logger, " ... executing AWS-UpdateSSMAgent command")

    update_ssm_automation_resp = __send_command(
        ssm_client, "AWS-UpdateSSMAgent", "$DEFAULT", {"allowDowngrade": ["false"]}, instance_ids)

    command_id = update_ssm_automation_resp['Command']['CommandId']

    if update_ssm_automation_resp['ResponseMetadata']['HTTPStatusCode'] != 200:
        print_log_error(logger,
                        "Failed to run automation doc to update ssm agent on the instance. HTTP response from SSM : {}".format(
                            update_ssm_automation_resp['ResponseMetadata']), True)

    print_log_info(logger, " ... verifying AWS-UpdateSSMAgent command id={} status".format(command_id))
    remaining_instances = instance_ids.copy()

    for x in range(VERIFY_SSM_PACKAGE_RETRY_COUNT):
        each_run_remaining = remaining_instances.copy()
        for each_instance_id in each_run_remaining:
            # Adding this sleep coz AWS fails with botocore.errorfactory.InvocationDoesNotExist: An error occurred (InvocationDoesNotExist) when calling the GetCommandInvocation operation without this timeout
            time.sleep(VERIFY_SSM_PACKAGE_SLEEP_SEC)
            command_invocation_resp = __get_command_invocation(ssm_client, command_id, each_instance_id)

            if command_invocation_resp['Status'] == 'Success' and command_invocation_resp['StatusDetails'] == 'Success':
                remaining_instances.remove(each_instance_id)

        if len(remaining_instances) == 0:
            break
        time.sleep(VERIFY_SSM_PACKAGE_SLEEP_SEC)
    if len(remaining_instances) > 0:
        print_log_error(logger, "command AWS-UpdateSSMAgent did not finish executing on {} instances".format(
            remaining_instances),
                        True)


###########################
# Logging helper Functions
###########################


def print_log_info(logger, message):
    """Prints to std out and logs to log file."""
    print('[INFO] ' + message)
    logger.info(message)


def print_log_error(logger, message, fatal):
    """Prints to std out and logs to log file."""

    print('[ERROR] ' + message)
    logger.error(message)
    if fatal:
        sys.exit(2)


def print_log_warn(logger, message):
    """Prints to std out and logs to log file."""

    print('[WARNING] ' + message)
    logger.warning(message)
