import logging
import os
import boto3
import aws_ssm_helper
import cfnresponse

logger = logging.getLogger()
logger.setLevel(logging.INFO)

SUCCESS = "SUCCESS"
FAILED = "FAILED"
document_name = os.environ['document_name']
region = os.environ['aws_region']
s3bucket = os.environ['s3bucket']
ssm_automation_doc_name = os.environ['ssm_automation_doc_name']
PACKAGE_FILEPATH = 'falcon/manifest.json'
AUTOMATION_FILEPATH = 'Local-Crowdstrike-FalconSensorDeploy.yml'


###########################
# Logging helper Functions
###########################


def delete_document(document_to_delete):
    try:
        ssm_client = boto3.client('ssm', region_name=region)
        response = ssm_client.delete_document(
            Name=document_to_delete,
            Force=True)
        if response['ResponseMetadata']['HTTPStatusCode'] == 200:
            logger.info('Deleted Document')
            return True
        else:
            return
    except Exception as e:
        logger.info('Got exception {} trying to delete ssm document - continue'.format(e))
        return False


def lambda_handler(event, context):
    logger.info('Got event {}'.format(event))
    # response_data = [{}, ]
    responseData = {}
    session = boto3.Session()
    if event['RequestType'] in ['Create']:
        logger.info('Event = ' + event['RequestType'])
        automation_ok = aws_ssm_helper.create_or_update_ssm_automation_document(session, s3bucket, logger, [region],
                                                                                'create',
                                                                                document_name,
                                                                                AUTOMATION_FILEPATH)

        dist_ok = aws_ssm_helper.create_ssm_distributor_package(session, logger, [region], ssm_automation_doc_name,
                                                                "v1",
                                                                PACKAGE_FILEPATH, s3bucket)

        if automation_ok and dist_ok:
            logger.info('sending cfn success')
            responseData['Result'] = 'OK'
            cfnresponse.send(event, context, cfnresponse.SUCCESS, responseData)

            return
        else:
            responseData['Result'] = 'Failed'
            cfnresponse.send(event, context, cfnresponse.FAILED, responseData)
            return
    elif event['RequestType'] in ['Update']:
        logger.info('Event = ' + event['RequestType'])
        aws_ssm_helper.create_or_update_ssm_automation_document(session, s3bucket, logger, [region], 'create',
                                                                document_name,
                                                                AUTOMATION_FILEPATH)
        responseData['Result'] = 'OK'
        cfnresponse.send(event, context, cfnresponse.SUCCESS, responseData)
        return
    elif event['RequestType'] in ['Delete']:
        # aws_ssm_helper.delete_ssm_document(session, logger, [region], document_name)
        delete_document(document_name)
        delete_document(ssm_automation_doc_name)
        logger.info('Event = ' + event['RequestType'])
        responseData['Result'] = 'OK'
        cfnresponse.send(event, context, cfnresponse.SUCCESS, responseData)
        return
